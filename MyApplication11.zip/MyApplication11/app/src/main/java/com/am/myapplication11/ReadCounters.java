package com.am.myapplication11;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ReadCounters extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.read_counters);
    }
}
